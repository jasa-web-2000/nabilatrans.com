<a href="<?php echo e(route('beranda')); ?>" class="block w-[50px] rounded-full overflow-hidden">
    <img class="w-full h-auto" loading="lazy" width="50" height="50" src="<?php echo e(asset('img/logo.png')); ?>"
        alt="Logo <?php echo e(config('app.name')); ?>">
</a>
<?php /**PATH C:\Users\Dion\Documents\nabilatrans.com\resources\views/components/logo.blade.php ENDPATH**/ ?>