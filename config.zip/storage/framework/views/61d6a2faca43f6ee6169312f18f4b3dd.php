<?php if (isset($component)) { $__componentOriginalf4088b6e5430c3c69553619df6e257df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf4088b6e5430c3c69553619df6e257df = $attributes; } ?>
<?php $component = App\View\Components\BackgroundBlue::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('background-blue'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BackgroundBlue::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="__container py-24">
        <?php if (isset($component)) { $__componentOriginal879506df025bc33800db5cbd420e556f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal879506df025bc33800db5cbd420e556f = $attributes; } ?>
<?php $component = App\View\Components\Heading::resolve(['title' => 'Pilih Rute','desc1' => 'Bebarapa Rute Unggulan','desc2' => 'Kami merekomendasikan beberapa rute '.e(tagline()).' dan seluruh Jawa yang jadi pilihan banyak orang.','light' => true,'full' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heading::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal879506df025bc33800db5cbd420e556f)): ?>
<?php $attributes = $__attributesOriginal879506df025bc33800db5cbd420e556f; ?>
<?php unset($__attributesOriginal879506df025bc33800db5cbd420e556f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal879506df025bc33800db5cbd420e556f)): ?>
<?php $component = $__componentOriginal879506df025bc33800db5cbd420e556f; ?>
<?php unset($__componentOriginal879506df025bc33800db5cbd420e556f); ?>
<?php endif; ?>
        <div class="mt-10">
            <?php if (isset($component)) { $__componentOriginal91a2d118c9c68d158ffcfa4063bf95ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91a2d118c9c68d158ffcfa4063bf95ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.travel-grid','data' => ['featured' => $featured]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.travel-grid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['featured' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($featured)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91a2d118c9c68d158ffcfa4063bf95ee)): ?>
<?php $attributes = $__attributesOriginal91a2d118c9c68d158ffcfa4063bf95ee; ?>
<?php unset($__attributesOriginal91a2d118c9c68d158ffcfa4063bf95ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91a2d118c9c68d158ffcfa4063bf95ee)): ?>
<?php $component = $__componentOriginal91a2d118c9c68d158ffcfa4063bf95ee; ?>
<?php unset($__componentOriginal91a2d118c9c68d158ffcfa4063bf95ee); ?>
<?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf4088b6e5430c3c69553619df6e257df)): ?>
<?php $attributes = $__attributesOriginalf4088b6e5430c3c69553619df6e257df; ?>
<?php unset($__attributesOriginalf4088b6e5430c3c69553619df6e257df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf4088b6e5430c3c69553619df6e257df)): ?>
<?php $component = $__componentOriginalf4088b6e5430c3c69553619df6e257df; ?>
<?php unset($__componentOriginalf4088b6e5430c3c69553619df6e257df); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Dion\Documents\nabilatrans.com\resources\views/components/layouts/home/featured.blade.php ENDPATH**/ ?>