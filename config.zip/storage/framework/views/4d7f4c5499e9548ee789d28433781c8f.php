<?php
    $address = json_decode(postal_address(), true);
    $menu = [
        [phone(), whatsapp()],
        [$address['addressLocality'], $address['linkAddress']],
        // [email(), 'mailto:' . email()],
    ];

?>

<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a target="_blank" rel="nofollow noreferrer" href="<?php echo e($item[1] ?? route(Str::slug($item[0]))); ?>"
            class="whitespace-nowrap hover:text-blue-50"><?php echo e($item[0]); ?></a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\Dion\Documents\nabilatrans.com\resources\views/components/kontak.blade.php ENDPATH**/ ?>