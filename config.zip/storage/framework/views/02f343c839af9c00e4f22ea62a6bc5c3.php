
<?php $__env->startSection('content'); ?>
    <?php
        $asal = Str::title($travel[0]['name']);
        $asalId = $travel[0]['id'];
        $tujuan = Str::title($travel[1]['name']);
        $tujuanId = $travel[1]['id'];

        $postal_address = json_decode(postal_address(), true);
    ?>
    <?php if (isset($component)) { $__componentOriginal87a045471305d9b16f09feaa62783e57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal87a045471305d9b16f09feaa62783e57 = $attributes; } ?>
<?php $component = App\View\Components\DefaultBaner::resolve(['title' => $page . ' PP Murah ' . date('Y'),'desc' => $desc . '.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('default-baner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DefaultBaner::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal87a045471305d9b16f09feaa62783e57)): ?>
<?php $attributes = $__attributesOriginal87a045471305d9b16f09feaa62783e57; ?>
<?php unset($__attributesOriginal87a045471305d9b16f09feaa62783e57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal87a045471305d9b16f09feaa62783e57)): ?>
<?php $component = $__componentOriginal87a045471305d9b16f09feaa62783e57; ?>
<?php unset($__componentOriginal87a045471305d9b16f09feaa62783e57); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal159f23c1702f2667f1808a4b0622f0f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159f23c1702f2667f1808a4b0622f0f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.article-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.article-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        
        <?php if (isset($component)) { $__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.article-left','data' => ['class' => 'col-span-full lg:col-span-6 lg:pr-24']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.article-left'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'col-span-full lg:col-span-6 lg:pr-24']); ?>
            
            <img src="<?php echo e($thumbnail); ?>" alt="<?php echo e($title); ?>" title="<?php echo e($title); ?>">

            <p>Saat ini
                <strong>
                    <a title="<?php echo e($page); ?>"
                        href="<?php echo e(route('jalur-rute-travel', [
                            'asal' => $asal,
                            'asalId' => $asalId,
                            'tujuan' => $tujuan,
                            'tujuanId' => $tujuanId,
                        ])); ?>">
                        <?php echo e($page); ?></a>
                </strong>
                telah tersedia untuk membantu perjalanan transportasi anda kemanapun dan kapanpun dengan pelayanan door to
                door dan pulang pergi (pp). Pastinya harganya terjangkau dan bisa dinegosiasikan dengan admin kami.
            </p>


            <p>
                Travel dari <?php echo e($asal); ?> saat ini sudah banyak bermunculan yang musiman. Mereka memberikan harga
                murah namun pelayanan sangat kurang baik. Jadi jangan sampai anda salah memilih agen travel. Pilih travel
                yang terpercaya, sudah punya website dan garasi atau loket resmi.
            </p>

            <p>Bagaimanapun, travel <?php echo e($tujuan); ?> adalah layanan transportasi darat dengan jarak yang jauh dan durasi
                yang lama. Jadi anda juga harus memikirkan sisi kenyamanan. Anda bisa menentukan jasa transportasi yang akan
                anda pakai. Jadi kami tidak bisa memaksakan anda untuk menggunakan layanan travel.</p>

            <h2>Penyedia <?php echo e($page); ?></h2>

            <p>Pada tahun <?php echo e(date('Y')); ?> telah banyak pilihan jasa travel reguler maupun carter. Namun ada satu travel
                reguler yang kami rekomendasikan, yaitu <a title="<?php echo e(env('APP_NAME')); ?>"
                    href="<?php echo e(route('beranda')); ?>"><?php echo e(env('APP_NAME')); ?></a>.
                <?php echo e(env('APP_NAME')); ?> ini telah berpengalaman dalam bidang transportasi darat. <?php echo e(env('APP_NAME')); ?>

                merupakan jasa travel terbaik no. 1 di daerah Pulau Jawa dan Bali, terutama daerah
                <?php echo e($postal_address['addressLocality']); ?>.</p>

            <img src="<?php echo e(asset('img/logo.jpg')); ?>" alt="Logo <?php echo e(env('APP_NAME')); ?>" title="Logo <?php echo e(env('APP_NAME')); ?>">

            <p>Kami siap membantu perjalanan travel anda kapanpun dan kemanapun. Kami memiliki driver yang berpengalaman
                untuk rute-rute travel seluruh daerah di Pulau Jawa dan Bali. Mereka telah berlisensi dan telah mengikuti
                pelatihan yang sesuai dengan jasa travel. </p>

            <p><?php echo e(env('APP_NAME')); ?> juga memiliki banyak <a href="<?php echo e(route('arsip-travel')); ?>"
                    title="travel terbaik">travel terbaik</a>, berikut beberapa contohnya:</p>

            <ul>
                <li>
                    <a title="Travel <?php echo e($tujuan); ?> <?php echo e($asal); ?>"
                        href="<?php echo e(route('jalur-rute-travel', [
                            'asal' => Str::slug($tujuan),
                            'tujuan' => Str::slug($asal),
                            'asalId' => $tujuanId,
                            'tujuanId' => $asalId,
                        ])); ?>">Travel
                        <?php echo e($tujuan); ?> <?php echo e($asal); ?></a>
                </li>

                <?php $__currentLoopData = $recommendation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a
                            href="<?php echo e(route('jalur-rute-travel', ['asal' => Str::slug($loop->index < 5 ? $travel[0]['name'] : $travel[1]['name']), 'tujuan' => Str::slug($item['name']), 'asalId' => $loop->index < 5 ? $travel[0]['id'] : $travel[1]['id'], 'tujuanId' => $item['id']])); ?>"><?php echo e(Str::title('Travel ' . ($loop->index < 5 ? $travel[0]['name'] : $travel[1]['name']) . ' ' . $item['name'])); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <img class="mt-5"
                src="<?php echo e(route('thumbnail-jalur-rute-travel', [
                    'asal' => Str::slug($travel[1]['name']),
                    'tujuan' => Str::slug($travel[0]['name']),
                    'asalId' => $travel[1]['id'],
                    'tujuanId' => $travel[0]['id'],
                ])); ?>"
                alt="Travel <?php echo e($tujuan); ?> <?php echo e($asal); ?>"
                title="Travel <?php echo e($tujuan); ?> <?php echo e($asal); ?>">

            <h2><?php echo e($title); ?></h2>

            <p>Sedang mencari travel hari ini? Tenang saja akan membantu anda untuk bepergian dari <?php echo e($asal); ?> ke
                <?php echo e($tujuan); ?> maupun dari <?php echo e($tujuan); ?> ke <?php echo e($asal); ?>. Tanpa perlu khawatir
                memikirkan
                harga, jadwal, biaya tol, dan rute travel. </p>


            <p>Bagi beberapa orang, jasa travel anda solusi perjalanan yang aman, cepat, dan fleksibel. Kenapa tidak? Anda
                bisa menjadwalkan perjalanan travel kapan saja dan tidak perlu menunggu. Kami langsung jemput dari rumah
                anda atau lokasi lain yang anda pilih.</p>

            <p>

                Untuk Hari <?php echo e(\Carbon\Carbon::now()->addDay()->locale('id')->isoFormat('dddd, D MMMM YYYY')); ?>, telah
                dibuka pemesanan tiket travel untuk rute ini. Jika anda berminat, bisa langsung hubungi admin kami dan
                jadwalkan perjalanan travel sekarang juga!
            </p>

            <h3>Armada/Mobil Travel Yang Digunakan Lengkap</h3>

            <p>Kami adalah jasa travel profesional, jadi kami telah memiliki banyak armada/mobil yang menunjang perjalanan
                travel. Tentunya semua mobil tersebut telah dilengkapi pengamanan dan fasilitas menarik seperti bagasi dan
                ac.</p>

            <p>Mobil travel juga dilengkapi dengan kursi yang nyaman dan bisa anda atur tingkat kemiringannya. Tidur di
                mobil jadi lebih nyaman. Jika anda ingin bepergian dengan jarak yang sangat jauh, sangat disarankan memilih
                jasa travel dari <?php echo e(env('APP_NAME')); ?>.</p>

            <p>Berikut daftar mobil/armada yang tersedia:</p>


            <ul>
                <li>Elf Giga</li>
                <li>Elf NLR (Macan)</li>
                <li>Avanza</li>
                <li>Xenia</li>
                <li>Mobilio</li>
                <li>Elf Short</li>
                <li>HiAce</li>
            </ul>


            <h3>Lokasi Titik Penjemputan dan Pengantaran</h3>

            <p>Sebetulnya, kami ini menawarkan jasa travel dengan sistem door to door. Door to door artinya anda akan
                dijemput langsung dari lokasi yang anda inginkan seperti rumah anda dan diantar langsung ke tempat yang anda
                inginkan juga. Jadi lebih fleksibel dan aman.</p>

            <p>Tidak perlu repot datang ke garasi kami untuk memulai keberangkatan, cukup dengan menunggu driver menjemput
                anda. Untuk layanan ini tidak dikenakan biaya tambahan.</p>

            <h3>Harga Tiket Travel</h3>

            <p>Untuk saat ini, harga travel mulai dari Rp100.000 - Rp250.000 tergantung rute yang anda pesan. Harga tidak
                selalu sama, pastikan untuk menghubungi admin sebelum melakukan pemesanan. Tidak hanya itu saja, anda juga
                bisa melakukan negosiasi harga travel kepada admin kami pada nomor <?php echo e(phone()); ?>.</p>

            <p>Harga diatas sudah include dengan berbagai bonus dan fasilitas menarik lainnya, seperti:</p>

            <ul>
                <li>Diskon tiket 10% untuk pemesanan hari ini</li>
                <li>Promo mingguan tersedia setiap Hari Minggu</li>
                <li>Free bagasi sebanyak 15 kg per orang</li>
                <li>Bonus snack dan air mineral 1 botol</li>
                <li>Bonus makan untuk beberapa rute travel</li>
                <li>Antar jemput langsung dari rumah</li>
                <li>Tiket tol penuh</li>
                <li>Biaya bensin</li>
                <li>Biaya parkir jika dibutuhkan</li>
                <li>Kursi dapat direbahkan</li>
            </ul>


            <h3>Cara Pemesanan Tiket Travel</h3>

            <p>Banyak sekali yang mengatasnamakan <?php echo e(env('APP_NAME')); ?> untuk mendapatkan penipuan. Bahkan ada yang
                menjadikannya sebagai modus penipuan. Harap terus berhati-hari untuk memesan travel. Kami hanya memiliki 1
                website dan 1 nomor telepon. Pesan <?php echo e($page); ?> melalui whatsapp pada nomor <a
                    title="whatsapp<?php echo e(phone()); ?>" href="<?php echo e(whatsapp()); ?>" target="_blank"
                    rel="nofollow noreferrer"><?php echo e(phone()); ?></a> atau anda
                bisa melakukan panggilan langsung.</p>

            <p>Selain itu, anda juga bisa melakukan pemesanan secara offline dengan cara mendatangi garasi kami. Kami
                memiliki garasi di setiap kota, namun garasi utama ada di <a title="<?php echo e($postal_address['streetAddress']); ?>"
                    href="<?php echo e($postal_address['linkAddress']); ?>" rel="nofollow noreferrer"
                    target="_blank"><?php echo e($postal_address['streetAddress']); ?></a></p>


            <h2>Pertanyaan Yang Sering Ditanyakan Calon Penumpang</h2>

            <p>Setiap calon penumpang selalu memastikan sebelum melakukan pemesanan, mungkin anda juga menanyakan hal yang
                sama. Berikut pertanyaan dan jawabannya, semoga membantu.</p>

            <dl>
                <dt><?php echo e(env('APP_NAME')); ?> Memiliki Garasi Dimana?</dt>
                <dd>Kami memiliki garasi di setiap kota, namun garasi utama ada di <?php echo e($postal_address['addressLocality']); ?>

                </dd>

                <dt>Berapa Harga <?php echo e($page); ?>?</dt>
                <dd>Untuk harga travel bervariasi mulai dari Rp100.000 hingga Rp250.000 per orang. Silahkan lakukan
                    negosiasi kepada admin.
                </dd>

                <dt>Apakah Tersedia Promo dan Diskon?</dt>
                <dd>Tentu saja! Kami memberikan diskon s/d 10% untuk hari ini. Tidak hanya itu saja, terdapat promo menarik
                    setiap Hari Minggu.
                </dd>

                <dt>Apakah Harus Membayar DP?</dt>
                <dd>Pembayaran DP tidak wajib. Anda bisa membayar ketika sudah sampai di lokasi. Untuk pembayaran silahkan
                    koordinasi kepada admin kami.
                </dd>

                <dt>Dapat Fasilitas dan Bonus Apa Saja?</dt>
                <dd>Setiap layanan travel reguler dipastikan free bagasi, minuman, snack, dan mobil yang ber-ac. Untuk
                    beberapa rute disediakan makan gratis.</dd>
            </dl>

            <p>Travel reguler sangat cocok bagi anda yang ingin bepergian jarak jauh, baik itu sendiri maupun bersama
                keluarga atau rekan. Pelayanan selalu menyesuaikan kebutuhan para penumpang. Jadi, sangat disarankan
                memesan <strong><?php echo e($page); ?></strong> bersama <?php echo e(env('APP_NAME')); ?>.</p>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b)): ?>
<?php $attributes = $__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b; ?>
<?php unset($__attributesOriginal17c4a23673a4440a1bb06c8c7bab4d4b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b)): ?>
<?php $component = $__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b; ?>
<?php unset($__componentOriginal17c4a23673a4440a1bb06c8c7bab4d4b); ?>
<?php endif; ?>



        
        <?php if (isset($component)) { $__componentOriginalce3cc09b41fabec0e4da8b4d854711be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce3cc09b41fabec0e4da8b4d854711be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.article-right','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.article-right'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a = $attributes; } ?>
<?php $component = App\View\Components\Booking::resolve(['page' => $page] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('booking'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Booking::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a)): ?>
<?php $attributes = $__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a; ?>
<?php unset($__attributesOriginal5379d7c313a3003ffeb1e9f8c8b1be8a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a)): ?>
<?php $component = $__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a; ?>
<?php unset($__componentOriginal5379d7c313a3003ffeb1e9f8c8b1be8a); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce3cc09b41fabec0e4da8b4d854711be)): ?>
<?php $attributes = $__attributesOriginalce3cc09b41fabec0e4da8b4d854711be; ?>
<?php unset($__attributesOriginalce3cc09b41fabec0e4da8b4d854711be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce3cc09b41fabec0e4da8b4d854711be)): ?>
<?php $component = $__componentOriginalce3cc09b41fabec0e4da8b4d854711be; ?>
<?php unset($__componentOriginalce3cc09b41fabec0e4da8b4d854711be); ?>
<?php endif; ?>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159f23c1702f2667f1808a4b0622f0f8)): ?>
<?php $attributes = $__attributesOriginal159f23c1702f2667f1808a4b0622f0f8; ?>
<?php unset($__attributesOriginal159f23c1702f2667f1808a4b0622f0f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159f23c1702f2667f1808a4b0622f0f8)): ?>
<?php $component = $__componentOriginal159f23c1702f2667f1808a4b0622f0f8; ?>
<?php unset($__componentOriginal159f23c1702f2667f1808a4b0622f0f8); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dion\Documents\nabilatrans.com\resources\views/pages/travel.blade.php ENDPATH**/ ?>