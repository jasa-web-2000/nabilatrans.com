<div>
    <div
        class="grid grid-cols-1 min-[400px]:grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-y-7 gap-x-5">

        <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $title = Str::title('TRAVEL ' . $item[0]['name'] . ' ' . $item[1]['name']);
            ?>
            <div class="rounded-lg overflow-hidden h-full">
                <div class="overflow-hidden w-full h-auto block">

                    <img width="160" height="90" loading="lazy" title="<?php echo e($title); ?>" loading="lazy"
                        src="<?php echo e(route('thumbnail-jalur-rute-travel', ['asal' => Str::slug($item[0]['name']), 'tujuan' => Str::slug($item[1]['name']), 'asalId' => $item[0]['id'], 'tujuanId' => $item[1]['id']])); ?>"
                        class="border-4 w-full h-auto aspect-video border-b-0 rounded-lg rounded-b-none hover:scale-110 transition-all duration-300"
                        alt="<?php echo e($title); ?>">

                </div>
                <div class="p-5 bg-white h-full">
                    <h3 class="mt-0 text-base font-semibold !leading-normal mb-3"><?php echo e($title); ?></h3>
                    <p class="text-[15px]">Pesan <?php echo e($title); ?> untuk hari ini dan dapatkan promo menarik</p>
                    <a href="<?php echo e(route('jalur-rute-travel', ['asal' => Str::slug($item[0]['name']), 'tujuan' => Str::slug($item[1]['name']), 'asalId' => $item[0]['id'], 'tujuanId' => $item[1]['id']])); ?>"
                        title="<?php echo e($title); ?>" target="__blank" class="underline text-[15px] opacity-80">Baca
                        selengkapnya...</a>
                    <a title="Pesan <?php echo e($title); ?>" target="_blank" rel="nofollow noreferrer"
                        href="<?php echo e(whatsapp()); ?>" target="__blank"
                        class="mt-4 rounded-lg hover:bg-blue-500 bg-blue-600 text-slate-100 px-5 py-2 text-sm line-clamp-2 !leading-5 text-center font-bold">Pesan
                        Travel</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\Users\Dion\Documents\nabilatrans.com\resources\views/components/layouts/travel-grid.blade.php ENDPATH**/ ?>