<div class="bg-slate-200">

    <div class="py-24 __container">
        <div class="">
            <?php if (isset($component)) { $__componentOriginal879506df025bc33800db5cbd420e556f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal879506df025bc33800db5cbd420e556f = $attributes; } ?>
<?php $component = App\View\Components\Heading::resolve(['title' => 'Testimoni Pelanggan','desc1' => 'Pendapat Mereka Tentang Layanan Kami','desc2' => 'Apa saja ulasan mereka setelah menggunakan layanan dari kami?'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Heading::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal879506df025bc33800db5cbd420e556f)): ?>
<?php $attributes = $__attributesOriginal879506df025bc33800db5cbd420e556f; ?>
<?php unset($__attributesOriginal879506df025bc33800db5cbd420e556f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal879506df025bc33800db5cbd420e556f)): ?>
<?php $component = $__componentOriginal879506df025bc33800db5cbd420e556f; ?>
<?php unset($__componentOriginal879506df025bc33800db5cbd420e556f); ?>
<?php endif; ?>
            <div class="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">

                <div
                    class="mx-auto max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl custom-container flex flex-col items-center justify-center text-center mb-10 mt-16">
                    <div class="grid gap-10 md:grid-cols-2 xl:grid-cols-3">
                        <?php if (isset($component)) { $__componentOriginal867564707b3e77941dae1c0fd0aebcff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal867564707b3e77941dae1c0fd0aebcff = $attributes; } ?>
<?php $component = App\View\Components\Testimoni::resolve(['text' => 'Rekomendasi '.e(tagline()).' Surabaya bersama '.e(env('APP_NAME')).', perjalanan terasa <mark class=\'px-2 mx-1 text-mine bg-yellow-100 rounded-md ring-yellow-200 ring-2\'>nyaman</mark> dan menyenangkan! Armada Elf Long-nya bersih, AC bekerja dengan baik, dan pengemudinya sangat berpengalaman. Sepanjang jalan, saya bisa bersantai tanpa gangguan atau rasa lelah. Pelayanan seperti ini bikin saya ingin memesan lagi di lain waktu.','name' => 'Danang','job' => 'Pengusaha','img' => ''.e(asset('img/testimonial/gal1.webp')).'','className' => 'xl:col-span-1 md:col-span-2'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('testimoni'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Testimoni::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $attributes = $__attributesOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $component = $__componentOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__componentOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal867564707b3e77941dae1c0fd0aebcff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal867564707b3e77941dae1c0fd0aebcff = $attributes; } ?>
<?php $component = App\View\Components\Testimoni::resolve(['text' => 'Layanan travel ini benar-benar bisa diandalkan! Saya memesan untuk mengantar orang tua ke bandara jelang keberangkatan umroh. Kendaraannya bersih, sopirnya sopan dan datang tepat waktu. Kami sekeluarga <mark class=\'px-2 mx-1 text-mine bg-yellow-100 rounded-md ring-yellow-200 ring-2\'>merasa tenang</mark> karena perjalanan berlangsung mulus tanpa terburu-buru. Terima kasih atas pelayanan yang luar biasa!','name' => 'Ahmad Fauzi','job' => 'Agen Travel Umroh','img' => ''.e(asset('img/testimonial/gal2.webp')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('testimoni'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Testimoni::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $attributes = $__attributesOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $component = $__componentOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__componentOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal867564707b3e77941dae1c0fd0aebcff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal867564707b3e77941dae1c0fd0aebcff = $attributes; } ?>
<?php $component = App\View\Components\Testimoni::resolve(['text' => 'Saya menggunakan jasa travel ini untuk pulang ke Tuban dari Bali saat Lebaran, dan alhamdulillah semuanya berjalan lancar. Sopirnya <mark class=\'px-2 mx-1 text-mine bg-yellow-100 rounded-md ring-yellow-200 ring-2\'>ramah</mark>, mobil yang digunakan <mark class=\'px-2 mx-1 text-mine bg-yellow-100 rounded-md ring-yellow-200 ring-2\'>bersih</mark> dan <mark class=\'px-2 mx-1 text-mine bg-yellow-100 rounded-md ring-yellow-200 ring-2\'>adem</mark>, bikin perjalanan jadi nyaman dan nggak terasa melelahkan. Orang tua saya juga ikut lega karena saya tiba dengan selamat dan tepat waktu. Terima kasih atas pelayanannya!','name' => 'Dewi Lestari','job' => 'Mahasiswi','img' => ''.e(asset('img/testimonial/gal3.webp')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('testimoni'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Testimoni::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $attributes = $__attributesOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__attributesOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal867564707b3e77941dae1c0fd0aebcff)): ?>
<?php $component = $__componentOriginal867564707b3e77941dae1c0fd0aebcff; ?>
<?php unset($__componentOriginal867564707b3e77941dae1c0fd0aebcff); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\Users\Dion\Documents\nabilatrans.com\resources\views/components/layouts/home/testimonials.blade.php ENDPATH**/ ?>