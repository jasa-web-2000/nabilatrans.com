<div class="__gradient">
    <div class="bg-right-bottom " style="background-image: url(<?php echo e(asset('img/blob.svg')); ?>)">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\Users\Dion\Documents\nabilatrans.com\resources\views/components/background-blue.blade.php ENDPATH**/ ?>