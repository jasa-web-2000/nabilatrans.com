<div class="<?php echo e($full ? 'mr-auto lg:mx-auto' : 'mx-auto'); ?> max-w-2xl lg:text-center">

    <h2 class="text-base font-semibold leading-7 <?php echo e($light ? 'text-blue-100' : 'text-blue-600'); ?>"><?php echo e($title); ?>

    </h2>
    <p class="mt-2 text-3xl font-bold tracking-tight <?php echo e($light ? 'text-blue-50' : 'text-gray-900'); ?> sm:text-4xl">
        <?php echo e($desc1); ?></p>
    <p class="mt-6 <?php echo e($light ? 'text-slate-100' : 'text-gray-600'); ?>"><?php echo e($desc2); ?></p>
</div>
<?php /**PATH C:\Users\Dion\Documents\nabilatrans.com\resources\views/components/heading.blade.php ENDPATH**/ ?>