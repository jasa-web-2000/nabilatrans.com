<x-layouts.sitemap :data="$data" />
