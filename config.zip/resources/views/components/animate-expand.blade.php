<div class="w-full h-[3px] bg-slate-300">
    <span class="h-full block animate-expand bg-blue-400"></span>
</div>
