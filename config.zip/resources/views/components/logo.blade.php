<a href="{{ route('beranda') }}" class="block w-[50px] rounded-full overflow-hidden">
    <img class="w-full h-auto" loading="lazy" width="50" height="50" src="{{ asset('img/logo.png') }}"
        alt="Logo {{ config('app.name') }}">
</a>
