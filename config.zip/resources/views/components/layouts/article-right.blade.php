<div class="col-span-full lg:col-span-3 pt-[60px] text-center">
    {{ $slot }}
</div>
