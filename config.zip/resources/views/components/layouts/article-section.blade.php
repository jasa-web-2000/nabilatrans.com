<article>
    <section id="content"
        class="__container !mx-auto md:!max-w-[800px] lg:!max-w-[1240px] grid grid-cols-9 text-justify !py-12">
        {{ $slot }}
    </section>
</article>
